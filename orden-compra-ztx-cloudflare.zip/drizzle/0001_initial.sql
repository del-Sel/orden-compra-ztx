CREATE TABLE IF NOT EXISTS purchase_orders (
  id TEXT PRIMARY KEY,
  share_token TEXT NOT NULL UNIQUE,
  number TEXT NOT NULL,
  issue_date TEXT,
  requested_by TEXT,
  payment TEXT,
  due_date TEXT,
  buyer TEXT,
  product TEXT,
  description TEXT,
  unit_price TEXT,
  total_quantity INTEGER NOT NULL DEFAULT 0,
  product_notes TEXT,
  general_notes TEXT,
  client_name TEXT,
  client_email TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  final_status TEXT NOT NULL DEFAULT 'Pendiente de entrega',
  signature_name TEXT,
  signature_dni TEXT,
  signed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT NOT NULL,
  delivery_number INTEGER NOT NULL,
  delivery_date TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  shipment TEXT,
  fiscal TEXT,
  status TEXT NOT NULL,
  notes TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (order_id) REFERENCES purchase_orders(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_purchase_orders_share_token ON purchase_orders(share_token);
CREATE INDEX IF NOT EXISTS idx_deliveries_order_id ON deliveries(order_id);
